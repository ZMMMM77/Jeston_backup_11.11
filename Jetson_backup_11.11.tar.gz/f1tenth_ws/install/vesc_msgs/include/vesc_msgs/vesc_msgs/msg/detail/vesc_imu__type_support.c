// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from vesc_msgs:msg/VescImu.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "vesc_msgs/msg/detail/vesc_imu__rosidl_typesupport_introspection_c.h"
#include "vesc_msgs/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "vesc_msgs/msg/detail/vesc_imu__functions.h"
#include "vesc_msgs/msg/detail/vesc_imu__struct.h"


// Include directives for member types
// Member `ypr`
// Member `linear_acceleration`
// Member `angular_velocity`
// Member `compass`
#include "geometry_msgs/msg/vector3.h"
// Member `ypr`
// Member `linear_acceleration`
// Member `angular_velocity`
// Member `compass`
#include "geometry_msgs/msg/detail/vector3__rosidl_typesupport_introspection_c.h"
// Member `orientation`
#include "geometry_msgs/msg/quaternion.h"
// Member `orientation`
#include "geometry_msgs/msg/detail/quaternion__rosidl_typesupport_introspection_c.h"

#ifdef __cplusplus
extern "C"
{
#endif

void vesc_msgs__msg__VescImu__rosidl_typesupport_introspection_c__VescImu_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  vesc_msgs__msg__VescImu__init(message_memory);
}

void vesc_msgs__msg__VescImu__rosidl_typesupport_introspection_c__VescImu_fini_function(void * message_memory)
{
  vesc_msgs__msg__VescImu__fini(message_memory);
}

static rosidl_typesupport_introspection_c__MessageMember vesc_msgs__msg__VescImu__rosidl_typesupport_introspection_c__VescImu_message_member_array[5] = {
  {
    "ypr",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(vesc_msgs__msg__VescImu, ypr),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "linear_acceleration",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(vesc_msgs__msg__VescImu, linear_acceleration),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "angular_velocity",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(vesc_msgs__msg__VescImu, angular_velocity),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "compass",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(vesc_msgs__msg__VescImu, compass),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "orientation",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(vesc_msgs__msg__VescImu, orientation),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers vesc_msgs__msg__VescImu__rosidl_typesupport_introspection_c__VescImu_message_members = {
  "vesc_msgs__msg",  // message namespace
  "VescImu",  // message name
  5,  // number of fields
  sizeof(vesc_msgs__msg__VescImu),
  false,  // has_any_key_member_
  vesc_msgs__msg__VescImu__rosidl_typesupport_introspection_c__VescImu_message_member_array,  // message members
  vesc_msgs__msg__VescImu__rosidl_typesupport_introspection_c__VescImu_init_function,  // function to initialize message memory (memory has to be allocated)
  vesc_msgs__msg__VescImu__rosidl_typesupport_introspection_c__VescImu_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t vesc_msgs__msg__VescImu__rosidl_typesupport_introspection_c__VescImu_message_type_support_handle = {
  0,
  &vesc_msgs__msg__VescImu__rosidl_typesupport_introspection_c__VescImu_message_members,
  get_message_typesupport_handle_function,
  &vesc_msgs__msg__VescImu__get_type_hash,
  &vesc_msgs__msg__VescImu__get_type_description,
  &vesc_msgs__msg__VescImu__get_type_description_sources,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_vesc_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, vesc_msgs, msg, VescImu)() {
  vesc_msgs__msg__VescImu__rosidl_typesupport_introspection_c__VescImu_message_member_array[0].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, geometry_msgs, msg, Vector3)();
  vesc_msgs__msg__VescImu__rosidl_typesupport_introspection_c__VescImu_message_member_array[1].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, geometry_msgs, msg, Vector3)();
  vesc_msgs__msg__VescImu__rosidl_typesupport_introspection_c__VescImu_message_member_array[2].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, geometry_msgs, msg, Vector3)();
  vesc_msgs__msg__VescImu__rosidl_typesupport_introspection_c__VescImu_message_member_array[3].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, geometry_msgs, msg, Vector3)();
  vesc_msgs__msg__VescImu__rosidl_typesupport_introspection_c__VescImu_message_member_array[4].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, geometry_msgs, msg, Quaternion)();
  if (!vesc_msgs__msg__VescImu__rosidl_typesupport_introspection_c__VescImu_message_type_support_handle.typesupport_identifier) {
    vesc_msgs__msg__VescImu__rosidl_typesupport_introspection_c__VescImu_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &vesc_msgs__msg__VescImu__rosidl_typesupport_introspection_c__VescImu_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
